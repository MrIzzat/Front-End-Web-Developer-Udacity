# Step 6 - Adding Convenience in Webpack

This section has three commits, they add the following webpack tools and configurations for a better development environment:

- The webpack dev server (commit 1)
- The Clean webpack plugin (commit 2)
- Light intro to Webpack Debugging tools (commit 3)

## IMPORTANT
**Please note that checking out the code at commit 3 will have errors in it. Errors were intentionally added for commit 3 to play around with various debugging settings.**
